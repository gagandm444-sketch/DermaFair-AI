# -*- coding: utf-8 -*-
"""
View Routes Blueprint
Renders HTML templates for all seven project pages.
"""

from flask import Blueprint, render_template, request
import os
import sys

cur_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(os.path.dirname(cur_dir))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from ml.classes import get_all_classes
from backend.database.db import get_recent_predictions

view_bp = Blueprint('views', __name__)

@view_bp.route('/')
def index():
    return render_template('index.html', active_page='index')

@view_bp.route('/detection')
def detection():
    history = get_recent_predictions(limit=5)
    return render_template('detection.html', active_page='detection', history=history)

@view_bp.route('/explainability')
def explainability():
    img_url = request.args.get('image', '/static/images/sample_melanoma.png')
    gradcam_url = request.args.get('gradcam', '/static/images/sample_heatmap.png')
    category = request.args.get('category', 'Melanoma, Nevi and Moles')
    return render_template(
        'explainability.html',
        active_page='explainability',
        img_url=img_url,
        gradcam_url=gradcam_url,
        category=category
    )

@view_bp.route('/fairness')
def fairness():
    return render_template('fairness.html', active_page='fairness')

@view_bp.route('/diseases')
def diseases():
    all_classes = get_all_classes()
    return render_template('diseases.html', active_page='diseases', diseases=all_classes)

@view_bp.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', active_page='dashboard')

@view_bp.route('/about')
def about():
    return render_template('about.html', active_page='about')
