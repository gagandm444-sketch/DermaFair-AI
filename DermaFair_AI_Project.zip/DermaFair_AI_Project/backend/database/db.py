# -*- coding: utf-8 -*-
"""
Database Management Module
Manages SQLite connection, schema creation, and prediction audit logging.
"""

import sqlite3
import os
import json
import uuid
from datetime import datetime

DATABASE_PATH = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'predictions.db')

def get_connection():
    """Returns a SQLite connection with row factory configured."""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initializes database tables if they do not exist."""
    db_dir = os.path.dirname(DATABASE_PATH)
    if not os.path.exists(db_dir):
        os.makedirs(db_dir)

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id TEXT PRIMARY KEY,
            category TEXT NOT NULL,
            confidence REAL NOT NULL,
            top3_json TEXT NOT NULL,
            image_url TEXT,
            gradcam_url TEXT,
            timestamp TEXT NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            details TEXT,
            timestamp TEXT NOT NULL
        )
    ''')

    conn.commit()
    conn.close()

def save_prediction(category, confidence, top3_list, image_url=None, gradcam_url=None):
    """
    Saves a prediction record into SQLite and returns the record dict.
    """
    init_db()
    pred_id = str(uuid.uuid4())
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO predictions (id, category, confidence, top3_json, image_url, gradcam_url, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        pred_id,
        category,
        float(confidence),
        json.dumps(top3_list),
        image_url or '',
        gradcam_url or '',
        now_str
    ))

    conn.commit()
    conn.close()

    return {
        "id": pred_id,
        "category": category,
        "confidence": float(confidence),
        "top3": top3_list,
        "image_url": image_url,
        "gradcam_url": gradcam_url,
        "timestamp": now_str
    }

def get_recent_predictions(limit=10):
    """Retrieves the most recent predictions."""
    init_db()
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT id, category, confidence, top3_json, image_url, gradcam_url, timestamp
        FROM predictions
        ORDER BY timestamp DESC
        LIMIT ?
    ''', (limit,))

    rows = cursor.fetchall()
    results = []
    for r in rows:
        results.append({
            "id": r["id"],
            "category": r["category"],
            "confidence": r["confidence"],
            "top3": json.loads(r["top3_json"]) if r["top3_json"] else [],
            "image_url": r["image_url"],
            "gradcam_url": r["gradcam_url"],
            "timestamp": r["timestamp"]
        })

    conn.close()
    return results
