# Dataset Guidelines & Acquisition Protocol

## Supported Benchmark Datasets

DermaFair AI is designed to support 23 granular dermatological families and require skin tone phototype annotations (Fitzpatrick scale I through VI).

### 1. Fitzpatrick17k Dataset
- **Paper:** *Groh et al., "Evaluating Deep Learning for Dermatological Diagnosis Across Skin Tones", Nature Medicine / FAccT 2021*
- **Size:** 16,577 clinical photographs annotated with 114 conditions mapped into 23 diagnostic categories.
- **Annotations:** Contains validated Fitzpatrick scale labels (`fitzpatrick_scale` from 1 to 6) and diagnosis labels.
- **Repository:** [GitHub - Fitzpatrick17k](https://github.com/mattgroh/fitzpatrick17k)

### 2. ISIC Archive (International Skin Imaging Collaboration)
- **URL:** [https://www.isic-archive.com/](https://www.isic-archive.com/)
- Contains thousands of dermoscopic images of benign and malignant melanocytic and non-melanocytic lesions.
- Used for melanoma, basal cell carcinoma, and actinic keratosis verification.

### 3. HAM10000
- **URL:** [https://www.kaggle.com/datasets/kmader/skin-cancer-mnist-ham10000](https://www.kaggle.com/datasets/kmader/skin-cancer-mnist-ham10000)
- Note: HAM10000 provides 7 diagnostic categories. It should be combined with broader benchmarks (such as Dermnet / Fitzpatrick17k) to achieve the full 23 clinical classes.

---

## Directory Organization for Training

Organize images by class name subfolder for direct use with `ImageDataGenerator` or `tf.keras.utils.image_dataset_from_directory`:

```
dataset/
├── Acne and Rosacea/
├── Actinic Keratosis and Malignant Lesions/
├── Atopic Dermatitis/
├── Bullous Disease/
├── Cellulitis and Bacterial Infections/
├── Eczema and Contact Dermatitis/
├── Exanthems and Drug Eruptions/
├── Hair Loss and Alopecia/
├── Herpes, HPV and Viral STDs/
├── Light Diseases and Pigmentation/
├── Lupus and Connective Tissue/
├── Melanoma, Nevi and Moles/
├── Nail Fungus and Nail Diseases/
├── Poison Ivy and Toxic Dermatitis/
├── Psoriasis and Lichen Planus/
├── Scabies and Parasitic Bites/
├── Seborrheic Keratoses and Benign Tumors/
├── Systemic Disease Cutaneous Signs/
├── Tinea and Fungal Infections/
├── Urticaria and Angioedema/
├── Vascular Tumors and Hemangiomas/
├── Vasculitis and Purpura/
└── Warts and Viral Papillomas/
```

---

## Preventing Data Leakage

Always partition dataset splits at the **Patient Level** (`patient_id`), rather than purely random image-level splitting. If the same patient has multiple clinical captures, placing one in the training set and another in the test set creates artificial performance inflation.
