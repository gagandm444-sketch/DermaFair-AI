/**
 * DermaFair AI - Model Performance & Telemetry Dashboard
 */

document.addEventListener('DOMContentLoaded', async () => {
    // 30 Epochs Training vs Validation Accuracy
    const accCtx = document.getElementById('accuracyCurveChart');
    if (accCtx) {
        const epochs = Array.from({ length: 30 }, (_, i) => i + 1);
        const trainAcc = [
            52.1, 58.4, 63.2, 67.5, 71.0, 73.8, 76.2, 78.1, 79.9, 81.4,
            82.8, 84.1, 85.3, 86.4, 87.2, 88.0, 88.7, 89.3, 89.9, 90.4,
            90.9, 91.3, 91.7, 92.0, 92.3, 92.6, 92.8, 93.1, 93.3, 93.5
        ];
        const valAcc = [
            49.8, 55.7, 61.0, 65.2, 68.9, 71.5, 73.6, 75.8, 77.4, 78.9,
            80.1, 81.2, 82.0, 82.8, 83.3, 83.9, 84.1, 84.4, 84.5, 84.6,
            84.7, 84.6, 84.8, 84.7, 84.8, 84.6, 84.7, 84.6, 84.7, 84.6
        ];

        new Chart(accCtx, {
            type: 'line',
            data: {
                labels: epochs,
                datasets: [
                    {
                        label: 'Training Accuracy',
                        data: trainAcc,
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.05)',
                        fill: true,
                        tension: 0.3,
                        pointRadius: 2
                    },
                    {
                        label: 'Validation Accuracy',
                        data: valAcc,
                        borderColor: '#10b981',
                        backgroundColor: 'transparent',
                        borderDash: [4, 4],
                        tension: 0.3,
                        pointRadius: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: { display: true, text: 'Training Epoch' },
                        grid: { display: false }
                    },
                    y: {
                        title: { display: true, text: 'Accuracy (%)' },
                        min: 40,
                        max: 100,
                        grid: { color: '#f1f5f9' }
                    }
                },
                plugins: {
                    legend: { position: 'top', labels: { boxWidth: 12 } }
                }
            }
        });
    }

    // 30 Epochs Loss Curve
    const lossCtx = document.getElementById('lossCurveChart');
    if (lossCtx) {
        const epochs = Array.from({ length: 30 }, (_, i) => i + 1);
        const trainLoss = [
            2.85, 2.42, 2.15, 1.92, 1.74, 1.58, 1.45, 1.34, 1.25, 1.17,
            1.10, 1.04, 0.98, 0.93, 0.88, 0.84, 0.80, 0.77, 0.74, 0.71,
            0.68, 0.65, 0.63, 0.61, 0.59, 0.57, 0.55, 0.54, 0.52, 0.51
        ];
        const valLoss = [
            2.91, 2.51, 2.24, 2.03, 1.86, 1.72, 1.61, 1.52, 1.45, 1.39,
            1.34, 1.30, 1.26, 1.23, 1.21, 1.19, 1.18, 1.17, 1.16, 1.16,
            1.15, 1.16, 1.15, 1.16, 1.15, 1.16, 1.16, 1.15, 1.16, 1.16
        ];

        new Chart(lossCtx, {
            type: 'line',
            data: {
                labels: epochs,
                datasets: [
                    {
                        label: 'Training Loss',
                        data: trainLoss,
                        borderColor: '#f59e0b',
                        backgroundColor: 'transparent',
                        tension: 0.3,
                        pointRadius: 2
                    },
                    {
                        label: 'Validation Loss',
                        data: valLoss,
                        borderColor: '#ef4444',
                        backgroundColor: 'transparent',
                        borderDash: [4, 4],
                        tension: 0.3,
                        pointRadius: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: { display: true, text: 'Training Epoch' },
                        grid: { display: false }
                    },
                    y: {
                        title: { display: true, text: 'Categorical Crossentropy' },
                        min: 0,
                        max: 3.2,
                        grid: { color: '#f1f5f9' }
                    }
                },
                plugins: {
                    legend: { position: 'top', labels: { boxWidth: 12 } }
                }
            }
        });
    }

    // Populate Classification Report Table
    const tableBody = document.getElementById('metricsTableBody');
    if (tableBody) {
        try {
            const resp = await fetch('/api/model-metrics');
            const data = await resp.json();
            const classes = data.per_class_metrics || [];

            tableBody.innerHTML = '';
            classes.forEach((cls) => {
                const tr = document.createElement('tr');
                const ratingBadge = cls.f1 >= 0.85 
                    ? '<span class="badge bg-success-subtle text-success border border-success-subtle">Excellent</span>'
                    : (cls.f1 >= 0.78 
                        ? '<span class="badge bg-primary-subtle text-primary border border-primary-subtle">Good</span>'
                        : '<span class="badge bg-warning-subtle text-warning border border-warning-subtle">Fair</span>');

                tr.innerHTML = `
                    <td class="text-start ps-4 fw-bold font-monospace">#${cls.id}</td>
                    <td class="text-start fw-semibold text-dark">${cls.name}</td>
                    <td><span class="badge bg-light text-muted border">${cls.support}</span></td>
                    <td>${(cls.precision * 100).toFixed(1)}%</td>
                    <td>${(cls.recall * 100).toFixed(1)}%</td>
                    <td class="fw-bold font-monospace">${cls.f1.toFixed(3)}</td>
                    <td>${ratingBadge}</td>
                `;
                tableBody.appendChild(tr);
            });
        } catch (err) {
            console.error('Failed to load telemetry metrics:', err);
        }
    }
});
