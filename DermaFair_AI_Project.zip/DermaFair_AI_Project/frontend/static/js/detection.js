/**
 * DermaFair AI - Detection & Inference Interface
 */

document.addEventListener('DOMContentLoaded', () => {
    const dropzone = document.getElementById('uploadDropzone');
    const imageInput = document.getElementById('imageInput');
    const browseBtn = document.getElementById('browseBtn');
    const previewCard = document.getElementById('previewCard');
    const imagePreview = document.getElementById('imagePreview');
    const removeBtn = document.getElementById('removeImageBtn');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const detectionForm = document.getElementById('detectionForm');
    const sampleBtns = document.querySelectorAll('.sample-btn');

    const emptyState = document.getElementById('emptyStateCard');
    const loadingState = document.getElementById('loadingStateCard');
    const resultsContainer = document.getElementById('resultsContainer');

    let currentFile = null;
    let selectedSample = null;

    // Browse click
    if (browseBtn) {
        browseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            imageInput.click();
        });
    }

    if (dropzone) {
        dropzone.addEventListener('click', () => {
            imageInput.click();
        });

        // Drag events
        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.remove('dragover');
            });
        });

        dropzone.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files && files.length > 0) {
                handleSelectedFile(files[0]);
            }
        });
    }

    // Input change
    if (imageInput) {
        imageInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files.length > 0) {
                handleSelectedFile(e.target.files[0]);
            }
        });
    }

    // Benchmark sample buttons
    sampleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const sampleType = btn.getAttribute('data-sample');
            loadSampleImage(sampleType);
        });
    });

    function loadSampleImage(sampleType) {
        selectedSample = sampleType;
        currentFile = null;
        imageInput.value = '';

        let samplePath = `/static/images/sample_${sampleType}.png`;
        if (sampleType === 'melanoma') samplePath = '/static/images/sample_melanoma.png';
        else if (sampleType === 'psoriasis') samplePath = '/static/images/sample_psoriasis.png';
        else if (sampleType === 'eczema') samplePath = '/static/images/sample_eczema.png';

        imagePreview.src = samplePath;
        dropzone.classList.add('d-none');
        previewCard.classList.remove('d-none');
        analyzeBtn.disabled = false;
    }

    function handleSelectedFile(file) {
        if (!file.type.match('image.*')) {
            alert('Please select a valid image file (JPEG, PNG, or WEBP).');
            return;
        }

        if (file.size > 16 * 1024 * 1024) {
            alert('File size exceeds 16MB limit.');
            return;
        }

        currentFile = file;
        selectedSample = null;

        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.src = e.target.result;
            dropzone.classList.add('d-none');
            previewCard.classList.remove('d-none');
            analyzeBtn.disabled = false;
        };
        reader.readAsDataURL(file);
    }

    // Remove image
    if (removeBtn) {
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            currentFile = null;
            selectedSample = null;
            imageInput.value = '';
            imagePreview.src = '';
            previewCard.classList.add('d-none');
            dropzone.classList.remove('d-none');
            analyzeBtn.disabled = true;

            emptyState.classList.remove('d-none');
            loadingState.classList.add('d-none');
            resultsContainer.classList.add('d-none');
        });
    }

    // Form submission
    if (detectionForm) {
        detectionForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!currentFile && !selectedSample) {
                alert('Please upload an image or select a benchmark sample first.');
                return;
            }

            // Show loading state
            emptyState.classList.add('d-none');
            resultsContainer.classList.add('d-none');
            loadingState.classList.remove('d-none');
            analyzeBtn.disabled = true;

            const formData = new FormData();
            if (currentFile) {
                formData.append('image', currentFile);
            } else if (selectedSample) {
                formData.append('sample', selectedSample);
            }

            try {
                const response = await fetch('/api/predict', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                loadingState.classList.add('d-none');
                analyzeBtn.disabled = false;

                if (!response.ok || !data.success) {
                    throw new Error(data.error || 'Failed to process clinical image.');
                }

                renderResults(data);
            } catch (err) {
                loadingState.classList.add('d-none');
                analyzeBtn.disabled = false;
                emptyState.classList.remove('d-none');
                alert('Inference Error: ' + err.message);
            }
        });
    }

    function renderResults(data) {
        const pred = data.prediction;

        // Primary fields
        document.getElementById('resultDiseaseName').textContent = pred.category;
        document.getElementById('resultConfidence').textContent = (pred.confidence * 100).toFixed(1) + '%';
        document.getElementById('resultCategoryGroup').textContent = pred.group_label || 'Clinical Family';
        document.getElementById('resultDescription').textContent = pred.description || 'Clinical classification generated.';
        document.getElementById('resultInferenceTime').textContent = `Inference: ${data.inference_time_ms}ms`;

        // Top-3 differential
        const top3Container = document.getElementById('top3List');
        top3Container.innerHTML = '';

        if (pred.top3 && pred.top3.length > 0) {
            pred.top3.forEach((item, index) => {
                const pct = (item.probability * 100).toFixed(1);
                const rankColor = index === 0 ? 'bg-primary' : (index === 1 ? 'bg-secondary' : 'bg-secondary-subtle text-dark');
                const barColor = index === 0 ? 'bg-primary' : (index === 1 ? 'bg-info' : 'bg-secondary');

                const itemRow = document.createElement('div');
                itemRow.className = 'p-2.5 rounded-3 bg-light border';
                itemRow.innerHTML = `
                    <div class="d-flex align-items-center justify-content-between mb-1">
                        <div class="d-flex align-items-center gap-2">
                            <span class="prediction-rank-badge ${rankColor}">#${index + 1}</span>
                            <span class="fw-bold small text-dark">${item.category}</span>
                        </div>
                        <span class="badge bg-white text-dark border font-monospace">${pct}%</span>
                    </div>
                    <div class="probability-bar-wrapper">
                        <div class="probability-bar-fill ${barColor}" style="width: ${pct}%;"></div>
                    </div>
                `;
                top3Container.appendChild(itemRow);
            });
        }

        // Setup XAI direct button
        const goToXaiBtn = document.getElementById('goToXaiBtn');
        if (goToXaiBtn && data.gradcam_url) {
            goToXaiBtn.href = `/explainability?image=${encodeURIComponent(data.image_url)}&gradcam=${encodeURIComponent(data.gradcam_url)}&category=${encodeURIComponent(pred.category)}`;
        }

        // Add to history table
        const historyTable = document.getElementById('historyTableBody');
        if (historyTable) {
            const newRow = document.createElement('tr');
            newRow.className = 'table-success bg-opacity-25';
            newRow.innerHTML = `
                <td><code>${data.audit_id ? data.audit_id.substring(0, 8) : 'AUDIT'}</code></td>
                <td class="fw-semibold">${pred.category}</td>
                <td><span class="badge bg-primary-subtle text-primary">${(pred.confidence * 100).toFixed(1)}%</span></td>
                <td class="text-muted">Just now</td>
            `;
            // Remove empty row if present
            const firstRow = historyTable.querySelector('tr');
            if (firstRow && firstRow.children.length === 1) {
                historyTable.innerHTML = '';
            }
            historyTable.insertBefore(newRow, historyTable.firstChild);
        }

        resultsContainer.classList.remove('d-none');
    }
});
