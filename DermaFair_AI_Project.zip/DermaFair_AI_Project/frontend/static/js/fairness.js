/**
 * DermaFair AI - Fairness Telemetry & Disparity Visualization
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Group Accuracy & Macro F1 Bar Chart
    const barCtx = document.getElementById('fairnessBarChart');
    if (barCtx) {
        new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: ['Fitzpatrick I–II (Light)', 'Fitzpatrick III–IV (Medium)', 'Fitzpatrick V–VI (Dark)'],
                datasets: [
                    {
                        label: 'Accuracy (%)',
                        data: [86.2, 84.8, 78.5],
                        backgroundColor: '#2563eb',
                        borderRadius: 6,
                        barPercentage: 0.6
                    },
                    {
                        label: 'Macro F1-Score (%)',
                        data: [86.1, 84.5, 77.3],
                        backgroundColor: '#0d9488',
                        borderRadius: 6,
                        barPercentage: 0.6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 65,
                        max: 95,
                        ticks: {
                            callback: function(value) { return value + '%'; }
                        },
                        grid: {
                            color: '#e2e8f0'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            boxWidth: 12,
                            font: { family: "'Inter', sans-serif", size: 12 }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.parsed.y + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // 2. False Negative Rate (FNR) Disparity Chart
    const fnrCtx = document.getElementById('fnrDisparityChart');
    if (fnrCtx) {
        new Chart(fnrCtx, {
            type: 'bar',
            data: {
                labels: ['Fitzpatrick I–II', 'Fitzpatrick III–IV', 'Fitzpatrick V–VI'],
                datasets: [
                    {
                        label: 'False Negative Rate (FNR %)',
                        data: [13.2, 14.9, 22.1],
                        backgroundColor: ['#10b981', '#3b82f6', '#ef4444'],
                        borderRadius: 6,
                        barPercentage: 0.5
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 30,
                        ticks: {
                            callback: function(value) { return value + '%'; }
                        },
                        grid: {
                            color: '#e2e8f0'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            afterLabel: function(context) {
                                if (context.dataIndex === 2) {
                                    return '+8.9% elevated miss rate vs Light Skin';
                                }
                                return '';
                            }
                        }
                    }
                }
            }
        });
    }

    // 3. Demographic Representation Doughnut/Pie Chart
    const pieCtx = document.getElementById('representationPieChart');
    if (pieCtx) {
        new Chart(pieCtx, {
            type: 'doughnut',
            data: {
                labels: [
                    'Types I–II (Light: 6,842)',
                    'Types III–IV (Medium: 7,118)',
                    'Types V–VI (Dark: 2,572)'
                ],
                datasets: [
                    {
                        data: [6842, 7118, 2572],
                        backgroundColor: ['#93c5fd', '#3b82f6', '#d97706'],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            padding: 15,
                            font: { family: "'Inter', sans-serif", size: 11 }
                        }
                    }
                }
            }
        });
    }
});
