/**
 * DermaFair AI - Global Application Scripts
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize tooltips if Bootstrap Tooltip is available
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Console branding
    console.log(
        '%c DermaFair AI %c Explainable Multi-Class Skin Disease Classification & Fairness ',
        'background: #1d4ed8; color: #fff; font-weight: bold; border-radius: 4px 0 0 4px; padding: 2px 6px;',
        'background: #0f172a; color: #38bdf8; border-radius: 0 4px 4px 0; padding: 2px 6px;'
    );
});
