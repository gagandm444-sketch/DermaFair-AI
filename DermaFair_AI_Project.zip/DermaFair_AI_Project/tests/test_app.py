# -*- coding: utf-8 -*-
"""
Test Suite for DermaFair AI
Verifies 23 disease taxonomy, inference pipeline, Grad-CAM generation, and fairness metrics.
"""

import os
import sys
import unittest

cur_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(cur_dir)
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from ml.classes import get_all_classes, get_class_by_id
from ml.predict import predict_skin_disease
from ml.gradcam import generate_gradcam_visualizations
from ml.fairness import get_fitzpatrick_fairness_benchmark, wilson_score_interval
from backend.database.db import init_db, save_prediction, get_recent_predictions

class TestDermaFairAI(unittest.TestCase):

    def test_23_disease_classes(self):
        """Verify that exactly 23 unique dermatological categories exist with metadata."""
        classes = get_all_classes()
        self.assertEqual(len(classes), 23, "Must support exactly 23 categories")
        ids = set(c["id"] for c in classes)
        self.assertEqual(len(ids), 23, "All class IDs must be unique from 0 to 22")
        for c in classes:
            self.assertTrue(len(c["name"]) > 3)
            self.assertTrue(len(c["description"]) > 10)
            self.assertIn(c["group"], ["inflammatory", "malignant", "infectious", "pigmentary", "appendages"])

    def test_inference_pipeline(self):
        """Verify image prediction returns top-1, top-3 differential, and confidence."""
        sample_path = os.path.join(root_dir, "static", "images", "sample_melanoma.png")
        if os.path.exists(sample_path):
            res = predict_skin_disease(sample_path)
            self.assertIn("category", res)
            self.assertIn("confidence", res)
            self.assertTrue(0.0 <= res["confidence"] <= 1.0)
            self.assertEqual(len(res["top3"]), 3, "Must provide Top-3 differential predictions")
            total_prob = sum(t["probability"] for t in res["top3"])
            self.assertTrue(total_prob <= 1.05)

    def test_gradcam_generation(self):
        """Verify Grad-CAM produces heatmap and overlay PNGs."""
        sample_path = os.path.join(root_dir, "static", "images", "sample_psoriasis.png")
        out_dir = os.path.join(root_dir, "static", "uploads")
        if os.path.exists(sample_path):
            hp, op = generate_gradcam_visualizations(sample_path, out_dir, "unit_test_run")
            self.assertTrue(os.path.exists(hp))
            self.assertTrue(os.path.exists(op))

    def test_fairness_metrics(self):
        """Verify empirical fairness benchmark across Fitzpatrick phototypes."""
        metrics = get_fitzpatrick_fairness_benchmark()
        self.assertEqual(len(metrics["cohorts"]), 3)
        self.assertAlmostEqual(metrics["disparity_gap_accuracy"], 7.7, delta=0.5)
        self.assertAlmostEqual(metrics["disparity_gap_fnr"], 8.9, delta=0.5)

    def test_database_logging(self):
        """Verify SQLite audit record creation and retrieval."""
        init_db()
        rec = save_prediction(
            category="Psoriasis and Lichen Planus",
            confidence=0.915,
            top3_list=[{"category": "Psoriasis and Lichen Planus", "probability": 0.915}],
            image_url="/static/images/sample_psoriasis.png",
            gradcam_url="/static/images/sample_overlay.png"
        )
        self.assertTrue(len(rec["id"]) > 10)
        recent = get_recent_predictions(limit=5)
        self.assertTrue(len(recent) >= 1)

if __name__ == '__main__':
    unittest.main()
