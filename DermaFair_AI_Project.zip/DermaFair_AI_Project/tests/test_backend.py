# -*- coding: utf-8 -*-
"""
Tests for DermaFair AI Backend & Chatbot API
"""
import os
import sys
import unittest

cur_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(cur_dir)
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

import backend_server

class TestBackendAndChatbot(unittest.TestCase):

    def test_text_consultation_clear_skin(self):
        resp = backend_server.handle_text_consultation('clear skin routine')
        self.assertEqual(resp['type'], 'routine')
        self.assertIn('Morning (AM) Regimen', resp['reply'])
        self.assertIn('Evening (PM) Regimen', resp['reply'])

    def test_text_consultation_acne(self):
        resp = backend_server.handle_text_consultation('how to heal acne breakouts')
        self.assertEqual(resp['type'], 'condition')
        self.assertIn('Acne & Rosacea Healing Protocol', resp['reply'])

    def test_text_consultation_mole_safety(self):
        resp = backend_server.handle_text_consultation('check my mole with abcde')
        self.assertEqual(resp['type'], 'safety')
        self.assertIn('Asymmetry', resp['reply'])
        self.assertIn('Border', resp['reply'])

    def test_image_heuristic_analyzer(self):
        # 1x1 base64 png
        tiny_b64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkWPjfDwAEeQHzE1k76AAAAABJRU5ErkJggg=='
        res = backend_server.analyze_skin_image_heuristic(tiny_b64)
        self.assertIn('disease', res)
        self.assertIn('confidence', res)
        self.assertIn('top3', res)
        self.assertIn('fitzpatrick', res)
        self.assertTrue(0.80 <= res['confidence'] <= 0.99)
        self.assertEqual(len(res['top3']), 3)

    def test_samples_and_diseases_available(self):
        self.assertEqual(len(backend_server.SAMPLES), 10)
        self.assertEqual(len(backend_server.DISEASES), 23)

if __name__ == '__main__':
    unittest.main()
