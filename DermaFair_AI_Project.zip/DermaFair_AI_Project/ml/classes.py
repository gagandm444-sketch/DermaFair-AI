# -*- coding: utf-8 -*-
"""
Authoritative 23 Dermatological Disease Categories
Conforming to standard benchmark taxonomy (Dermnet / Fitzpatrick17k 23 major clinical families).
"""

DISEASE_CLASSES = [
    {
        "id": 0,
        "name": "Acne and Rosacea",
        "group": "inflammatory",
        "group_label": "Inflammatory",
        "border_class": "disease-tag-inflammatory",
        "description": "Chronic inflammatory disorders of the pilosebaceous units characterized by open/closed comedones, erythematous papules, pustules, and facial flushing.",
        "characteristics": "Facial distribution, telangiectasia, papulopustular lesions, rhinophyma in chronic rosacea.",
        "red_flags": "Severe cystic lesions with deep scarring, sudden fulminant eruption, or ocular involvement (ocular rosacea).",
        "severity": "moderate"
    },
    {
        "id": 1,
        "name": "Actinic Keratosis and Malignant Lesions",
        "group": "malignant",
        "group_label": "Pre-Malignant / Carcinoma",
        "border_class": "disease-tag-malignant",
        "description": "UV-induced pre-cancerous intraepidermal keratoses and non-melanoma skin cancers including Basal Cell Carcinoma and Squamous Cell Carcinoma.",
        "characteristics": "Rough, scaly, sandpaper-like erythematous plaques on sun-exposed zones; pearly papules with arborizing vessels.",
        "red_flags": "Rapid induration, persistent ulceration, bleeding without trauma, failure to heal within 6 weeks.",
        "severity": "critical"
    },
    {
        "id": 2,
        "name": "Atopic Dermatitis",
        "group": "inflammatory",
        "group_label": "Inflammatory",
        "border_class": "disease-tag-inflammatory",
        "description": "Chronic relapsing pruritic eczematous skin disorder frequently associated with atopic diathesis, asthma, and allergic rhinitis.",
        "characteristics": "Flexural lichenification, xerosis, intense pruritus, excoriation, and periorbital dermatitis.",
        "red_flags": "Superimposed herpes simplex infection (eczema herpeticum), extensive honey-colored crusting (secondary impetigo).",
        "severity": "moderate"
    },
    {
        "id": 3,
        "name": "Bullous Disease",
        "group": "inflammatory",
        "group_label": "Autoimmune",
        "border_class": "disease-tag-inflammatory",
        "description": "Autoantibody-mediated blistering dermatoses targeting desmosomal or basement membrane adhesion proteins (e.g., Bullous Pemphigoid, Pemphigus Vulgaris).",
        "characteristics": "Tense or flaccid vesicles and bullae, Nikolsky sign, painful mucosal erosions.",
        "red_flags": "Widespread skin detachment resembling burns, mucosal involvement impairing swallowing or breathing (medical emergency).",
        "severity": "urgent"
    },
    {
        "id": 4,
        "name": "Cellulitis and Bacterial Infections",
        "group": "infectious",
        "group_label": "Bacterial Infection",
        "border_class": "disease-tag-infectious",
        "description": "Acute bacterial infection of dermis and subcutaneous tissue (predominantly S. pyogenes and S. aureus), including impetigo and folliculitis.",
        "characteristics": "Spreading poorly demarcated erythema, localized warmth, edema, tenderness, and regional lymphadenopathy.",
        "red_flags": "Rapid proximal spread, bullae formation, crepitus, systemic fevers, or signs of septic shock.",
        "severity": "urgent"
    },
    {
        "id": 5,
        "name": "Eczema and Contact Dermatitis",
        "group": "inflammatory",
        "group_label": "Inflammatory",
        "border_class": "disease-tag-inflammatory",
        "description": "Superficial skin inflammation triggered by external allergen contact (allergic) or direct chemical disruption of stratum corneum (irritant).",
        "characteristics": "Geometric demarcation, vesicular weeping in acute phase, scaling and fissuring in chronic phase.",
        "red_flags": "Severe facial swelling, occupational incapacitation, or secondary erythroderma (>90% body surface area).",
        "severity": "moderate"
    },
    {
        "id": 6,
        "name": "Exanthems and Drug Eruptions",
        "group": "inflammatory",
        "group_label": "Adverse Reaction",
        "border_class": "disease-tag-inflammatory",
        "description": "Cutaneous manifestations of systemic viral infections or immune-mediated adverse reactions to newly initiated pharmaceutical agents.",
        "characteristics": "Symmetric morbilliform or maculopapular eruption trunk-to-extremities, mucosal involvement in severe variants.",
        "red_flags": "Skin tenderness, facial edema, fever, eosinophilia, or epidermal detachment (SJS/TEN or DRESS syndrome).",
        "severity": "critical"
    },
    {
        "id": 7,
        "name": "Hair Loss and Alopecia",
        "group": "appendages",
        "group_label": "Hair & Appendages",
        "border_class": "",
        "description": "Non-scarring (Alopecia Areata, Telogen Effluvium, Androgenetic) and scarring (Lichen Planopilaris) disorders affecting follicular integrity.",
        "characteristics": "Exclamation mark hairs, discrete circular bald patches, diffuse shedding, or bitemporal recession.",
        "red_flags": "Permanent follicular scarring (erythema, perifollicular scale, lack of follicular ostia), rapid total body hair loss.",
        "severity": "low"
    },
    {
        "id": 8,
        "name": "Herpes, HPV and Viral STDs",
        "group": "infectious",
        "group_label": "Viral Infection",
        "border_class": "disease-tag-infectious",
        "description": "Cutaneous and mucosal viral infections caused by Herpesviridae (HSV-1, HSV-2, VZV) and Human Papillomavirus strains.",
        "characteristics": "Grouped umbilicated vesicles on an erythematous base, dermatomal zoster distribution, condylomata.",
        "red_flags": "Ophthalmic branch trigeminal distribution (Hutchinson sign for herpes zoster ophthalmicus), immunocompromised dissemination.",
        "severity": "urgent"
    },
    {
        "id": 9,
        "name": "Light Diseases and Pigmentation",
        "group": "pigmentary",
        "group_label": "Pigmentation",
        "border_class": "",
        "description": "Photodermatoses and disorders of melanin synthesis, including Melasma, Vitiligo, and post-inflammatory hyperpigmentation.",
        "characteristics": "Chalky white depigmented macules with well-defined borders (vitiligo), reticular hyperpigmented facial patches (melasma).",
        "red_flags": "Rapidly spreading depigmentation with underlying autoimmune thyroiditis, suspicious dark irregular pigmentation.",
        "severity": "low"
    },
    {
        "id": 10,
        "name": "Lupus and Connective Tissue",
        "group": "inflammatory",
        "group_label": "Autoimmune",
        "border_class": "disease-tag-inflammatory",
        "description": "Cutaneous manifestations of connective tissue autoimmunity (Systemic Lupus, Discoid Lupus, Dermatomyositis, Scleroderma).",
        "characteristics": "Malar butterfly rash sparing nasolabial folds, discoid plaques with follicular plugging, Gottron papules, heliotrope rash.",
        "red_flags": "Severe photosensitivity with arthralgias, renal involvement, digital ulcerations, or Raynaud phenomenon.",
        "severity": "urgent"
    },
    {
        "id": 11,
        "name": "Melanoma, Nevi and Moles",
        "group": "malignant",
        "group_label": "Melanocytic Neoplasm",
        "border_class": "disease-tag-malignant",
        "description": "Spectrum ranging from benign melanocytic nevi to aggressive cutaneous malignant melanoma arising from transformed melanocytes.",
        "characteristics": "Evaluation via ABCDE: Asymmetry, Border irregularity, Color variegation, Diameter >6mm, Evolving morphology.",
        "red_flags": "Rapid nodular elevation, spontaneous ulceration, bleeding, or 'ugly duckling' lesion deviating from other nevi.",
        "severity": "critical"
    },
    {
        "id": 12,
        "name": "Nail Fungus and Nail Diseases",
        "group": "appendages",
        "group_label": "Nail & Appendages",
        "border_class": "",
        "description": "Onychomycosis (dermatophyte nail invasion), paronychia, onycholysis, and systemic nail dystrophies (Beau lines, Terry nails).",
        "characteristics": "Subungual hyperkeratosis, yellow-brown xanthonychia, distal crumbling, acute periungual erythema and fluctuance.",
        "red_flags": "Acute paronychia tracking into tendon sheath (felon), longitudinal melanonychia in single digit (subungual melanoma risk).",
        "severity": "low"
    },
    {
        "id": 13,
        "name": "Poison Ivy and Toxic Dermatitis",
        "group": "inflammatory",
        "group_label": "Toxic / Allergic",
        "border_class": "disease-tag-inflammatory",
        "description": "Type IV cell-mediated hypersensitivity caused by urushiol resins in Toxicodendron plants or direct toxic cutaneous caustic agents.",
        "characteristics": "Linear vesicular streaks corresponding to brushing against plant leaves, intense pruritus, edema.",
        "red_flags": "Inhalation of smoke from burning poison ivy resulting in pulmonary mucosal edema, extensive facial involvement.",
        "severity": "moderate"
    },
    {
        "id": 14,
        "name": "Psoriasis and Lichen Planus",
        "group": "inflammatory",
        "group_label": "Papulosquamous",
        "border_class": "disease-tag-inflammatory",
        "description": "Immune-mediated chronic papulosquamous disorders characterized by hyperproliferation of keratinocytes (Psoriasis) or interface dermatitis (Lichen Planus).",
        "characteristics": "Salmon-colored plaques with thick silvery scales (Auspitz sign), purple polygonal pruritic papules (6 Ps of lichen planus).",
        "red_flags": "Pustular generalized flares (von Zumbusch), erythrodermic psoriasis with hemodynamic instability, destructive psoriatic arthritis.",
        "severity": "moderate"
    },
    {
        "id": 15,
        "name": "Scabies and Parasitic Bites",
        "group": "infectious",
        "group_label": "Parasitic Infestation",
        "border_class": "disease-tag-infectious",
        "description": "Cutaneous infestation by Sarcoptes scabiei mites, tick bites (Borrelia burgdorferi vector), and arthropod bite reactions.",
        "characteristics": "Intense nocturnal pruritus, serpiginous burrows in interdigital web spaces, wrists, axillae, genital papules.",
        "red_flags": "Erythema migrans (bulls-eye target lesion indicating Lyme disease), crusted (Norwegian) scabies in immunosuppressed individuals.",
        "severity": "moderate"
    },
    {
        "id": 16,
        "name": "Seborrheic Keratoses and Benign Tumors",
        "group": "malignant",
        "group_label": "Benign Neoplasm",
        "border_class": "",
        "description": "Extremely common benign epithelial neoplasms consisting of mature keratinocytes, including dermatofibromas and epidermoid cysts.",
        "characteristics": "'Stuck-on' waxy, verrucous, brown-to-black plaques with pseudohorn cysts, dimple sign in dermatofibromas.",
        "red_flags": "Sign of Leser-Trélat (sudden eruption of hundreds of seborrheic keratoses marking internal malignancy, e.g. gastric adenocarcinoma).",
        "severity": "low"
    },
    {
        "id": 17,
        "name": "Systemic Disease Cutaneous Signs",
        "group": "inflammatory",
        "group_label": "Systemic Signs",
        "border_class": "disease-tag-inflammatory",
        "description": "Dermatological markers of internal endocrinopathies, metabolic disease, or systemic inflammation (e.g. Necrobiosis Lipoidica, Acanthosis Nigricans).",
        "characteristics": "Velvety hyperpigmented flexural plaques, pretibial yellow-brown atrophic plaques with telangiectasia, xanthomas.",
        "red_flags": "Pyoderma gangrenosum ulceration, palpable purpura indicating systemic vasculitis or endocarditis.",
        "severity": "urgent"
    },
    {
        "id": 18,
        "name": "Tinea and Fungal Infections",
        "group": "infectious",
        "group_label": "Fungal Infection",
        "border_class": "disease-tag-infectious",
        "description": "Superficial dermatophytosis of stratum corneum (Trichophyton, Microsporum, Epidermophyton) including ringworm, athlete's foot, and jock itch.",
        "characteristics": "Annular erythematous scaly plaques with central clearing and active advancing elevated borders, satellite pustules in candidiasis.",
        "red_flags": "Majocchi granuloma (fungal invasion into deep dermal hair follicles), invasive mucormycosis in diabetic ketoacidosis.",
        "severity": "moderate"
    },
    {
        "id": 19,
        "name": "Urticaria and Angioedema",
        "group": "inflammatory",
        "group_label": "Vascular / Allergic",
        "border_class": "disease-tag-inflammatory",
        "description": "Mast cell degranulation yielding transient pruritic wheals (dermal edema) and deep subcutaneous/mucosal swelling (angioedema).",
        "characteristics": "Evanescent blanching wheals that resolve within 24 hours without residual bruising, dermatographia.",
        "red_flags": "Laryngeal edema, stridor, wheezing, hypotension, or anaphylactic shock (requires immediate intramuscular epinephrine).",
        "severity": "critical"
    },
    {
        "id": 20,
        "name": "Vascular Tumors and Hemangiomas",
        "group": "malignant",
        "group_label": "Vascular Neoplasm",
        "border_class": "",
        "description": "Benign proliferations of blood vessel endothelium including Cherry Angiomas, Pyogenic Granulomas, and Infantile Hemangiomas.",
        "characteristics": "Bright red domed papules, pedunculated raspberry-like bleeding vascular nodules, compressible blue nodules.",
        "red_flags": "Periorbital hemangiomas obstructing visual axis, airway hemangiomas, or Kaposi sarcoma in immunocompromised patients.",
        "severity": "moderate"
    },
    {
        "id": 21,
        "name": "Vasculitis and Purpura",
        "group": "inflammatory",
        "group_label": "Vascular / Autoimmune",
        "border_class": "disease-tag-inflammatory",
        "description": "Inflammation and fibrinoid necrosis of cutaneous blood vessel walls resulting in vessel rupture, extravasation of RBCs, and ischemia.",
        "characteristics": "Non-blanching palpable purpura primarily on dependent lower extremities, livedo reticularis, necrotic ulcers.",
        "red_flags": "Systemic involvement with renal hematuria/proteinuria, gastrointestinal bleeding, or mononeuritis multiplex.",
        "severity": "urgent"
    },
    {
        "id": 22,
        "name": "Warts and Viral Papillomas",
        "group": "infectious",
        "group_label": "Viral Infection",
        "border_class": "disease-tag-infectious",
        "description": "Benign cutaneous epithelial proliferations induced by Human Papillomavirus (HPV) or Poxvirus (Molluscum Contagiosum).",
        "characteristics": "Hyperkeratotic verrucous exophytic papules with pinpoint thrombosed capillaries ('black dots'), dome-shaped umbilicated lesions.",
        "red_flags": "Giant condyloma acuminatum (Buschke-Löwenstein tumor), extensive lesions in HIV/immunodeficient patients.",
        "severity": "low"
    }
]

def get_class_by_id(class_id):
    for c in DISEASE_CLASSES:
        if c["id"] == class_id:
            return c
    return DISEASE_CLASSES[0]

def get_all_classes():
    return DISEASE_CLASSES
