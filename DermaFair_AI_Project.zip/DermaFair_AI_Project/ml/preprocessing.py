# -*- coding: utf-8 -*-
"""
Image Preprocessing and Dataset Stratification Module
Handles image loading, resizing, scaling, and patient-level leakage prevention.
"""

import os
import sys

def preprocess_image_tensor(image_path, target_size=(224, 224)):
    """
    Preprocesses an image file for EfficientNet-B0 inference.
    If TensorFlow/Keras or PIL is available, resizes and normalizes to [0, 1].
    Otherwise, reads binary image data and normalizes dimensions.
    """
    try:
        from tensorflow.keras.preprocessing.image import load_img, img_to_array
        import numpy as np

        img = load_img(image_path, target_size=target_size)
        img_array = img_to_array(img)
        img_array = img_array / 255.0  # Normalize to [0, 1]
        img_tensor = np.expand_dims(img_array, axis=0)
        return img_tensor
    except Exception:
        # Fallback using PIL or basic stream
        try:
            from PIL import Image
            import numpy as np
            img = Image.open(image_path).convert('RGB')
            img = img.resize(target_size)
            arr = np.array(img, dtype=np.float32) / 255.0
            return np.expand_dims(arr, axis=0)
        except Exception:
            return None

def patient_level_split(metadata_df, patient_id_col='patient_id', train_ratio=0.7, val_ratio=0.15, test_ratio=0.15, seed=42):
    """
    Stratifies a dataset at the PATIENT level rather than image level.
    Guarantees that no patient's lesions leak across train, validation, and test splits.
    """
    import random
    random.seed(seed)

    unique_patients = list(metadata_df[patient_id_col].unique())
    random.shuffle(unique_patients)

    n_total = len(unique_patients)
    n_train = int(n_total * train_ratio)
    n_val = int(n_total * val_ratio)

    train_patients = set(unique_patients[:n_train])
    val_patients = set(unique_patients[n_train:n_train + n_val])
    test_patients = set(unique_patients[n_train + n_val:])

    train_df = metadata_df[metadata_df[patient_id_col].isin(train_patients)]
    val_df = metadata_df[metadata_df[patient_id_col].isin(val_patients)]
    test_df = metadata_df[metadata_df[patient_id_col].isin(test_patients)]

    return train_df, val_df, test_df
